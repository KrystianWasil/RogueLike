// Entity.h

#ifndef ROGUELIKE_ENTITY_H
#define ROGUELIKE_ENTITY_H

#include <iostream>
#include "FunctionFight.h"
#include "Item.h"
#include <cstdlib>
#include <ctime>
#include <utility>
#include <array>

class Entity {
private:
    char representation = 'x';
    std::string name;
    double health;
    int energy;
    double physical_damage;
    double magical_damage;
    int order;
    double armor;
    int speed;
    int level;
    std::array<Item,6> equipment;
    std::array<Item,20> bag;
    Item *hand;

public:
    Entity(char representation, const std::string &name, double health, int energy, double physicalDamage,
           double magicalDamage, int order, double armor, int speed, int level, const std::array<Item, 6> &equipment,
           const std::array<Item, 20> &bag) : representation(representation), name(name), health(health),
                                              energy(energy), physical_damage(physicalDamage),
                                              magical_damage(magicalDamage), order(order), armor(armor), speed(speed),
                                              level(level), equipment(equipment), bag(bag) {}

    const std::string &getName() const {
        return name;
    }

    char getRepresentation() const {
        return representation;
    }

    int getOrder() {
        return order;
    }

    bool isAlive() {
        if (health > 0) {
            return true;
        }
        return false;
    }

    void setOrder(int order) {
        Entity::order = order;
    }

    double givenDamage() const {
        if (magical_damage != 0) {
            return magical_damage + physical_damage;
        } else
            return physical_damage;
    }

    double blockedDamage() const {
        return armor;
    }

    void getDamage(double givenDamageFromEnemy) {
       this->health -= givenDamageFromEnemy;
    }





    void attack(Entity *victim) {
        double givenDamageToEnemy = 0;
        if (DidYouHit(this->chanceOfAttack(), victim->chanceOfAvoid(), victim->armor)) {
             givenDamageToEnemy = (this->givenDamage() - victim->blockedDamage());
             if (givenDamageToEnemy < 0) {
                 givenDamageToEnemy = 1;
             }
            this->energy -=3;
        } else {
            this->energy +=1;
        }
        victim->getDamage(givenDamageToEnemy);
    }

     int chanceOfAvoid() const {
        return speed + level;
    }

     int chanceOfAttack() const {
        return level + energy + speed;
    }

     int getHealth() const {
        return health;
    }

     int getEnergy() const {
        return energy;
    }

     double getArmor() const {
        return armor;
    }

    void setHealth(double health) {
        this->health = health;
    }
};

#endif //ROGUELIKE_ENTITY_H
