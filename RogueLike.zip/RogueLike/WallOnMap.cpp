//
// Created by wasil on 30.11.2023.
//

#include "WallOnMap.h"
