//
// Created by wasil on 23.11.2023.
//

#ifndef ROGUELIKE_HERO_H
#define ROGUELIKE_HERO_H


#include "Entity.h"

class Hero : public Entity {
public:
    Hero() : Entity('@',"hero",100, 10, 20, 0, 0, 10, 5,0,{},{}) {}
};


#endif //ROGUELIKE_HERO_H
