#include <iostream>
#include "Hero.h"
#include "Prisoner.h"
#include "TestFight.h"
#include "Map.h"
#include "WoodenDoor.h"
#include "WallOnMap.h"
#include "HungryDog.h"
#include "OldWizard.h"
#include "MutantBat.h"
#include "Guard.h"


void delete_all_characters() {

}

int main() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
    Map map(20,20);
    map.InitMap();
    map.DisplayMap();
    auto *element = new WoodenDoor;
    auto *element2 = new WallOnMap;
    Hero *h = new Hero;
    auto *p = new Prisoner;
    auto *d = new HungryDog;
    auto *w = new OldWizard;
    auto *m = new MutantBat;
    auto *g = new Guard;



    resultsOfFights results = FightStatistics( *h, *p, 10000);
    std::cout << "Wygrane bohatera: " <<  results.e1Wins << " " << "Wygrane przeciwnika: " << results.e2Wins << " " << " Maksymalna ilosc uderzen: " <<  *std::max_element(std::begin(results.arr), std::end(results.arr)) << " " << "Minimalna ilosc uderzen: " << *std::min_element(std::begin(results.arr), std::end(results.arr));
    resultsOfFights results1 = FightStatistics( *h, *d, 10000);
    std::cout << std::endl;
    std::cout << "Wygrane bohatera: " <<  results1.e1Wins << " " << "Wygrane przeciwnika: " << results1.e2Wins << " " << " Maksymalna ilosc uderzen: " <<  *std::max_element(std::begin(results1.arr), std::end(results1.arr)) << " " << "Minimalna ilosc uderzen: " << *std::min_element(std::begin(results.arr), std::end(results.arr));
    resultsOfFights results2 = FightStatistics( *h, *w, 10000);
    std::cout << std::endl;
    std::cout << "Wygrane bohatera: " <<  results.e1Wins << " " << "Wygrane przeciwnika: " << results2.e2Wins << " " << " Maksymalna ilosc uderzen: " <<  *std::max_element(std::begin(results2.arr), std::end(results2.arr)) << " " << "Minimalna ilosc uderzen: " << *std::min_element(std::begin(results.arr), std::end(results.arr));
    resultsOfFights results3 = FightStatistics( *h, *m, 10000);
    std::cout << std::endl;
    std::cout << "Wygrane bohatera: " <<  results.e1Wins << " " << "Wygrane przeciwnika: " << results3.e2Wins << " " << " Maksymalna ilosc uderzen: " <<  *std::max_element(std::begin(results3.arr), std::end(results3.arr)) << " " << "Minimalna ilosc uderzen: " << *std::min_element(std::begin(results.arr), std::end(results.arr));
    resultsOfFights results4 = FightStatistics( *h, *g, 10000);
    std::cout << std::endl;
    std::cout << "Wygrane bohatera: " <<  results.e1Wins << " " << "Wygrane przeciwnika: " << results4.e2Wins << " " << " Maksymalna ilosc uderzen: " <<  *std::max_element(std::begin(results4.arr), std::end(results4.arr)) << " " << "Minimalna ilosc uderzen: " << *std::min_element(std::begin(results.arr), std::end(results.arr));
    map.AddActor(h,4,5);
    map.AddActor(w,7,5);
    map.AddElement(element,3,2);
    map.AddElement(element2,1,5);
    std::cout << std::endl;
    map.DisplayMap();















    delete h;
    delete p;
    delete d;
    delete w;
    delete m;
    delete g;
    delete element;
    delete element2;



    return 0;
}

