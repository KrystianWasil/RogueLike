//
// Created by wasil on 24.11.2023.
//

#ifndef ROGUELIKE_FUNCTIONFIGHT_H
#define ROGUELIKE_FUNCTIONFIGHT_H


bool DidYouHit(int, int, int);


#endif //ROGUELIKE_FUNCTIONFIGHT_H
