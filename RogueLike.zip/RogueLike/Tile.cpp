//
// Created by wasil on 10.11.2023.
//



#include "Tile.h"

void Tile::AddObstacles(Obstacles *obstacle) {

}



