//
// Created by wasil on 10.11.2023.
//

#ifndef GAMEROGUELIKE_WOODENDOOR_H
#define GAMEROGUELIKE_WOODENDOOR_H


#include "Obstacles.h"

class WoodenDoor : public Obstacles {
public:
    WoodenDoor() : Obstacles('/') {}
};


#endif //GAMEROGUELIKE_WOODENDOOR_H
