//
// Created by wasil on 05.12.2023.
//

#ifndef ROGUELIKE_ITEM_H
#define ROGUELIKE_ITEM_H


class Item {
private:
    double extraDamage;
    double extraArmor;
    double heal;
    double speed;
public:
    double getExtraDamage() const {
        return extraDamage;
    }

    void setExtraDamage(double extraDamage) {
        this->extraDamage = extraDamage;
    }

    double getExtraArmor() const {
        return extraArmor;
    }

    void setExtraArmor(double extraArmor) {
        this->extraArmor = extraArmor;
    }

};


#endif //ROGUELIKE_ITEM_H
