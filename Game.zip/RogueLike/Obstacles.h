//
// Created by wasil on 10.11.2023.
//

#ifndef GAMEROGUELIKE_OBSTACLES_H
#define GAMEROGUELIKE_OBSTACLES_H


class Obstacles {
private:
    char representation;
public:
    Obstacles(char representation) : representation(representation){}
};


#endif //GAMEROGUELIKE_OBSTACLES_H
