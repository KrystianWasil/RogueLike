#ifndef GAMEROGUELIKE_FLOOR_H
#define GAMEROGUELIKE_FLOOR_H

#include "Field.h"

class Floor : public Field {
private:
    std::vector<Obstacles> obstacles;
public:
    Floor() : Field(' ', obstacles) {}

};

#endif //GAMEROGUELIKE_FLOOR_H