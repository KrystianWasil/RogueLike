#ifndef GAMEROGUELIKE_WALL_H
#define GAMEROGUELIKE_WALL_H

#include "Field.h"

class Wall : public Field {
public:
    Wall() : Field('#',{}) {}
};

#endif //GAMEROGUELIKE_WALL_H